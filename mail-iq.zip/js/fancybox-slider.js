Fancybox.bind('[data-fancybox="algorithm"]', {
  caption: function (fancybox, carousel, slide) {
    return `${slide.index + 1} / ${carousel.slides.length} <br />` + slide.caption;
  },
});
